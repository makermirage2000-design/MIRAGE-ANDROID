# Mirage Hunter — projeto Android (gera o APK)

**Importante:** este projeto foi escrito, mas **o APK não foi compilado nem testado em aparelho** (o ambiente onde foi
feito não tem SDK Android nem internet). O lado Python (o cérebro do bot) foi validado nos seus vídeos; o lado Android
(captura de tela, toque, tela do app, build) **nunca rodou**. A primeira compilação pode falhar — se falhar, me envie o
erro (passo 6) que eu corrijo.

## O que o app faz
Serviço de acessibilidade que (1) tira prints da tela do jogo, (2) roda o bot (mesmo código Python validado, via Chaquopy
+ OpenCV + Tesseract), (3) toca nos monstros. Só age quando o jogo (`com.foxcake.mirage.android` ou
`br.local.mirage.cameraampla`) está em primeiro plano. Exige **Android 11 ou superior**.

## Como gerar o APK (sem programar) — precisa de um COMPUTADOR e conta gratuita no GitHub
1. Crie uma conta em github.com e clique em **New repository** (pode ser Private). Nome: `MirageHunter`.
2. Extraia este ZIP no computador. No repositório novo, clique em **uploading an existing file** e arraste **todo o
   conteúdo** da pasta extraída (inclusive a pasta oculta **`.github`**). Clique em **Commit changes**.
   - Se a pasta `.github` não aparecer para arrastar: **Add file → Create new file**, nome
     `.github/workflows/build-apk.yml`, cole o conteúdo do arquivo de mesmo nome e confirme.
3. Aba **Actions** → **Gerar APK** → **Run workflow**. Aguarde ~10–15 minutos (✓ verde = pronto).
4. Abra a execução concluída → no fim da página, **Artifacts → MirageHunter-APK** → baixe e extraia: dentro está `app-debug.apk`.
5. Passe o APK para o celular e instale (permita "instalar de fontes desconhecidas").
6. **Se der ✗ vermelho:** abra a execução → passo **Compilar** → copie as últimas ~60 linhas do log e me envie.

## Primeiro uso no celular
1. Android 13+: **Configurações → Apps → Mirage Hunter → ⋮ → Permitir configurações restritas**.
2. Abra o app → **1. Abrir configurações de acessibilidade** → **Mirage Hunter** → ativar.
3. Deixe **MODO TESTE** ligado (o bot só observa e registra, sem tocar). Toque **INICIAR** e abra o jogo.
4. O status mostra estado, alvo, nomes lidos, mortes, trocas e ms por quadro. **Compartilhar diagnóstico** envia o log.
5. Só depois de conferir no modo teste, desligue o MODO TESTE para o bot tocar de verdade.

## Riscos conhecidos (não verificados)
- O jogo pode bloquear prints (tela preta) ou ignorar toques de acessibilidade.
- O Android limita prints a ~3 por segundo; o app usa ~2 quadros/s.
- Versões de bibliotecas (Android Gradle Plugin 8.2.2, Chaquopy 15.0.1, OpenCV do Chaquopy, Tesseract4Android 4.7.0) podem
  precisar de ajuste — o log de erro do build dirá qual.
- Desempenho do Python/OpenCV no seu aparelho é desconhecido.
