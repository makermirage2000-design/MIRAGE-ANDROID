"""Ponte entre o app Android (Java) e o bot (pacote miragebot, o MESMO código validado nos vídeos).
Só tipos simples atravessam a ponte: números, textos e caminhos de arquivo."""
import json
import os
import time

import cv2
import numpy as np

from miragebot.config import Config, TargetSpec
from miragebot.diagnostics import Diagnostics
from miragebot.io import Actuator, DryRunActuator
from miragebot.pipeline import HuntBot


class _Ocr:
    """OCR feito pelo Tesseract do Android (Java). A imagem vai por arquivo PNG pequeno."""
    def __init__(self, java_ocr, workdir):
        self.j = java_ocr
        self.path = os.path.join(workdir, "ocr_line.png")

    def read(self, mask):
        m = cv2.resize(mask, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST)
        m = cv2.copyMakeBorder(255 - m, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
        cv2.imwrite(self.path, m)
        out = str(self.j.recognize(self.path))          # "texto<TAB>confiança(0-100)"
        txt, _, conf = out.partition("\t")
        try:
            c = max(0.0, float(conf)) / 100.0
        except ValueError:
            c = 0.0
        return txt.strip(), c


class _Tap(Actuator):
    def __init__(self, java_tap):
        self.j = java_tap

    def tap(self, x, y):
        return bool(self.j.tap(float(x), float(y)))


class _Runner:
    def __init__(self, bot, diag):
        self.bot, self.diag = bot, diag

    def process(self, path, w, h, stride, t):
        t0 = time.perf_counter()
        raw = np.fromfile(str(path), dtype=np.uint8).reshape(int(h), int(stride), 4)[:, :int(w)]
        bgr = cv2.cvtColor(np.ascontiguousarray(raw), cv2.COLOR_RGBA2BGR)
        dec = self.bot.process(bgr, float(t))
        fsm, obs = self.bot.fsm, self.bot.last_obs
        trk = fsm.track
        last = self.diag.events[-1]["msg"] if self.diag.events else ""
        return json.dumps({
            "estado": dec.state,
            "alvo": (f"#{trk.serial} {trk.name}" if trk else "-"),
            "nomes": sum(1 for d in obs.detections if d.name) if obs else 0,
            "retrato": bool(obs.portrait_active) if obs else False,
            "mortes": int(fsm.stats.get("mortes", 0)),
            "trocas": int(fsm.stats.get("trocas", 0)),
            "toques": int(self.bot.gate.sent),
            "ms": int((time.perf_counter() - t0) * 1000),
            "msg": last[:160],
        }, ensure_ascii=False)


def create(java_ocr, java_tap, workdir, targets_csv, dry):
    workdir = str(workdir)
    names = [n.strip() for n in str(targets_csv).split(",") if n.strip()]
    cfg = Config.default()
    if names:
        cfg.targets = [TargetSpec(n) for n in names]
    diag = Diagnostics(os.path.join(workdir, "diagnostico.jsonl"), echo=False)
    actuator = DryRunActuator() if dry else _Tap(java_tap)
    bot = HuntBot(cfg, actuator, diag, engine=_Ocr(java_ocr, workdir))
    return _Runner(bot, diag)
