"""Movimento da cena (câmera). Quando o personagem anda, o mundo inteiro desliza na tela;
sem compensar isso o rastreador "perderia" o alvo. Usa correlação de fase em escala reduzida."""
from __future__ import annotations
from typing import Optional, Tuple

import cv2
import numpy as np

from .config import Config
from .geometry import Layout


class SceneMotion:
    def __init__(self, cfg: Config):
        self.k = cfg.vision.motion_downscale
        self.min_resp = cfg.vision.motion_min_response
        self.prev: Optional[np.ndarray] = None
        self.win: Optional[np.ndarray] = None

    def update(self, bgr: np.ndarray, lay: Layout) -> Tuple[float, float, bool]:
        """Devolve (dx, dy, confiável) em px nativos: quanto o CONTEÚDO deslocou desde o frame anterior."""
        small = cv2.resize(bgr, (lay.w // self.k, lay.h // self.k), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY).astype(np.float32)
        for x0, y0, x1, y1 in lay.excluded:          # HUD é estático: não deve "puxar" a correlação
            gray[y0 // self.k:y1 // self.k + 1, x0 // self.k:x1 // self.k + 1] = gray.mean()
        if self.win is None or self.win.shape != gray.shape:
            self.win = cv2.createHanningWindow((gray.shape[1], gray.shape[0]), cv2.CV_32F)
        out = (0.0, 0.0, False)
        if self.prev is not None and self.prev.shape == gray.shape:
            (dx, dy), resp = cv2.phaseCorrelate(self.prev, gray, self.win)
            if resp >= self.min_resp:
                out = (dx * self.k, dy * self.k, True)
        self.prev = gray
        return out
