"""Tipos compartilhados entre percepção, rastreador e máquina de estados."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np

from .names import NameDetection
from .selection import FrameHit

Rect = Tuple[int, int, int, int]


@dataclass
class Observation:
    """Tudo que a percepção viu em UM frame. A máquina de estados só consome isto (sem imagens),
    por isso é determinística e testável sem o jogo."""
    t: float
    detections: List[NameDetection]
    portrait_active: bool
    portrait_sig: Tuple[float, float] = (-1.0, 0.0)      # (matiz, fração colorida) do disco do alvo
    frames: List[FrameHit] = field(default_factory=list)
    shift: Tuple[float, float] = (0.0, 0.0)
    shift_ok: bool = True
    perception_ok: bool = True
    player: Tuple[float, float] = (1336.0, 609.0)
    tile: float = 111.0
    blind_rects: List[Rect] = field(default_factory=list)
    frame_size: Tuple[int, int] = (2688, 1216)
    probe_thumb: Optional[np.ndarray] = None     # miniatura do que está na posição prevista do alvo

    def blind(self, x: float, y: float, margin: float = 0.0) -> bool:
        """A posição está fora da tela ou sob a interface (não dá para ver nada ali)?"""
        w, h = self.frame_size
        if x < margin or y < margin or x > w - margin or y > h - margin:
            return True
        return any(x0 - margin <= x <= x1 + margin and y0 - margin <= y <= y1 + margin
                   for x0, y0, x1, y1 in self.blind_rects)


@dataclass
class TapCommand:
    x: float
    y: float
    serial: int
    reason: str


@dataclass
class Decision:
    state: str
    sent: List[TapCommand] = field(default_factory=list)
    note: str = ""
