"""Rastreamento do alvo. A identidade vem de: moldura do jogo > nome igual + continuidade de posição
(compensando o movimento da câmera) > aparência/barra de vida. Um monstro que aparece "mais perto"
NUNCA vira o alvo: só candidatos de MESMO NOME dentro do raio de busca do alvo atual são considerados."""
from __future__ import annotations
import math
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, List, Optional, Tuple

import numpy as np

from .config import Config
from .names import NameDetection, thumb_diff
from .selection import FrameHit
from .types import Observation


@dataclass
class Track:
    serial: int
    name: str
    pos: Tuple[float, float]
    t0: float
    origin: str = "bot"                         # 'bot' | 'externo'
    vel: Tuple[float, float] = (0.0, 0.0)
    last_seen: float = 0.0
    last_t: float = 0.0
    thumb: Optional[np.ndarray] = None
    fill_hist: Deque[Tuple[float, float]] = field(default_factory=lambda: deque(maxlen=64))
    first_fill: Optional[float] = None
    last_conf: float = 0.0
    taps: int = 0
    engaged_at: Optional[float] = None
    last_damage_t: Optional[float] = None
    selected_confirmed: bool = False

    def recent_min_fill(self, t: float, window: float = 2.5) -> Optional[float]:
        v = [f for (ts, f) in self.fill_hist if t - ts <= window]
        return min(v) if v else None

    def last_fill(self) -> Optional[float]:
        return self.fill_hist[-1][1] if self.fill_hist else None


@dataclass
class Match:
    found: bool = False
    how: str = ""                                # 'nome' | 'moldura' | ''
    det: Optional[NameDetection] = None
    pos: Tuple[float, float] = (0.0, 0.0)
    cost: float = 1.0
    dist_tiles: float = 0.0
    n_candidates: int = 0
    frame_on_target: bool = False                # o jogo desenhou a moldura NESTE monstro
    foreign_frame: Optional[FrameHit] = None     # moldura em OUTRO lugar (o jogo selecionou outro monstro)
    foreign_det: Optional[NameDetection] = None
    note: str = ""


class TargetTracker:
    def __init__(self, cfg: Config):
        self.c = cfg.tracking

    def new_track(self, serial: int, det: NameDetection, t: float, origin: str) -> Track:
        trk = Track(serial=serial, name=det.name or "?", pos=det.body, t0=t, origin=origin,
                    last_seen=t, last_t=t, thumb=det.thumb, last_conf=det.confidence)
        if det.bar_present and det.bar_fill is not None:
            trk.fill_hist.append((t, det.bar_fill)); trk.first_fill = det.bar_fill
        return trk

    # ---- movimento ----
    def advance(self, trk: Track, obs: Observation) -> None:
        """Move a posição prevista: câmera (shift) + velocidade do monstro (decaindo durante oclusão)."""
        dt = max(0.0, obs.t - trk.last_t)
        trk.last_t = obs.t
        x, y = trk.pos
        if obs.shift_ok:
            x += obs.shift[0]; y += obs.shift[1]
        decay = math.exp(-self.c.velocity_decay_per_s * max(0.0, obs.t - trk.last_seen))
        trk.pos = (x + trk.vel[0] * dt * decay, y + trk.vel[1] * dt * decay)

    def radius(self, trk: Track, obs: Observation) -> float:
        since = max(0.0, obs.t - trk.last_seen)
        tiles = min(self.c.max_radius_tiles, self.c.base_radius_tiles + self.c.growth_tiles_per_s * since)
        return tiles * obs.tile

    # ---- associação ----
    def match(self, trk: Track, obs: Observation) -> Match:
        pred, r, tile = trk.pos, self.radius(trk, obs), obs.tile
        m = Match()
        cands: List[Tuple[float, NameDetection, float]] = []
        for d in obs.detections:
            if d.name != trk.name:
                continue                                # outro nome/rejeitado: nunca é o alvo
            dist = math.hypot(d.body[0] - pred[0], d.body[1] - pred[1])
            if dist > r:
                continue
            app = min(1.0, thumb_diff(trk.thumb, d.thumb) / 0.5)
            fill = 0.0
            lf = trk.last_fill()
            if lf is not None and d.bar_fill is not None:
                fill = min(1.0, abs(lf - d.bar_fill) / 0.5)
            cost = 0.60 * dist / max(r, 1.0) + 0.25 * app + 0.15 * fill
            cands.append((cost, d, dist))
        m.n_candidates = len(cands)
        cands.sort(key=lambda c: c[0])

        # moldura do jogo mais próxima da previsão
        frame = None
        if obs.frames:
            frame = min(obs.frames, key=lambda f: math.hypot(f.center[0] - pred[0], f.center[1] - pred[1]))
        best = cands[0] if cands and cands[0][0] <= self.c.max_cost else None

        if best:
            cost, det, dist = best
            m.found, m.how, m.det, m.pos, m.cost, m.dist_tiles = True, "nome", det, det.body, cost, dist / tile
            if frame is not None and math.hypot(frame.center[0] - det.body[0], frame.center[1] - det.body[1]) <= 0.7 * tile:
                m.frame_on_target = True
        elif frame is not None and obs.portrait_active and \
                math.hypot(frame.center[0] - pred[0], frame.center[1] - pred[1]) <= max(0.8 * tile, 0.6 * r):
            m.found, m.how, m.pos = True, "moldura", frame.center       # nome oculto, mas o jogo marca o alvo
            m.dist_tiles = math.hypot(frame.center[0] - pred[0], frame.center[1] - pred[1]) / tile
            m.frame_on_target = True
            m.note = "nome não lido; identidade pela moldura do jogo"

        # o jogo selecionou OUTRO monstro?
        if frame is not None and not m.frame_on_target:
            far = math.hypot(frame.center[0] - (m.pos[0] if m.found else pred[0]),
                             frame.center[1] - (m.pos[1] if m.found else pred[1])) > 0.8 * tile
            if far:
                m.foreign_frame = frame
                near = [d for d in obs.detections if d.name and
                        math.hypot(d.body[0] - frame.center[0], d.body[1] - frame.center[1]) <= 0.7 * tile]
                m.foreign_det = near[0] if near else None
        return m

    def apply(self, trk: Track, m: Match, obs: Observation) -> None:
        if not m.found:
            return
        dt = max(1e-3, obs.t - trk.last_seen)
        # resíduo em relação à posição já compensada pela câmera
        rx, ry = m.pos[0] - trk.pos[0], m.pos[1] - trk.pos[1]
        if dt > 0.03:
            vx, vy = rx / dt, ry / dt
            cap = 6.0 * obs.tile
            vx, vy = max(-cap, min(cap, vx)), max(-cap, min(cap, vy))
            trk.vel = (0.5 * trk.vel[0] + 0.5 * vx, 0.5 * trk.vel[1] + 0.5 * vy)
        trk.pos = m.pos
        trk.last_seen = obs.t
        if m.det is not None:
            trk.last_conf = m.det.confidence
            if m.det.thumb is not None:
                trk.thumb = m.det.thumb
            if m.det.bar_fill is not None:        # inclui a vida estimada pela cor do nome (barra quase vazia)
                prev = trk.last_fill()
                trk.fill_hist.append((obs.t, m.det.bar_fill))
                if prev is not None and m.det.bar_fill < prev - 0.02:
                    trk.last_damage_t = obs.t
