"""Diagnóstico: cada decisão tem motivo. Saída em JSONL (máquina) + linhas legíveis (humano)."""
from __future__ import annotations
import json, time, collections
from typing import Any, Dict, Optional


class Diagnostics:
    def __init__(self, jsonl_path: Optional[str] = None, echo: bool = True, keep: int = 400):
        self.f = open(jsonl_path, "w", encoding="utf-8") if jsonl_path else None
        self.echo = echo
        self.events = collections.deque(maxlen=keep)
        self.counters: Dict[str, int] = collections.Counter()
        self._last_key: Dict[str, float] = {}
        self.stage_ms: Dict[str, list] = collections.defaultdict(list)

    # ---- eventos ----
    def log(self, t: float, kind: str, msg: str, state: str = "", **data: Any) -> None:
        self.counters[kind] += 1
        ev = {"t": round(t, 3), "kind": kind, "state": state, "msg": msg}
        if data:
            ev["data"] = data
        self.events.append(ev)
        if self.f:
            self.f.write(json.dumps(ev, ensure_ascii=False, default=_js) + "\n")
            self.f.flush()
        if self.echo:
            extra = " ".join(f"{k}={_fmt(v)}" for k, v in data.items())
            print(f"[{t:7.2f}s] {state:<28} {kind:<18} {msg} {extra}".rstrip())

    def log_limited(self, key: str, interval: float, t: float, kind: str, msg: str, state: str = "", **data):
        """Evita inundar o log com a mesma observação (ex.: mesmo candidato rejeitado)."""
        if t - self._last_key.get(key, -1e9) >= interval:
            self._last_key[key] = t
            self.log(t, kind, msg, state, **data)

    def timing(self, stage: str, ms: float) -> None:
        self.stage_ms[stage].append(ms)

    def perf_summary(self) -> str:
        parts = []
        for k, v in self.stage_ms.items():
            v = sorted(v)
            parts.append(f"{k}: média {sum(v)/len(v):.1f}ms p95 {v[int(len(v)*0.95)-1 if len(v)>1 else 0]:.1f}ms")
        return " | ".join(parts)

    def close(self):
        if self.f:
            self.f.close()


def _js(o):
    try:
        import numpy as np
        if isinstance(o, (np.floating,)): return float(o)
        if isinstance(o, (np.integer,)): return int(o)
        if isinstance(o, np.ndarray): return o.tolist()
    except Exception:
        pass
    return str(o)


def _fmt(v):
    if isinstance(v, float): return f"{v:.2f}"
    if isinstance(v, (tuple, list)): return "(" + ",".join(_fmt(x) for x in v) + ")"
    return str(v)
