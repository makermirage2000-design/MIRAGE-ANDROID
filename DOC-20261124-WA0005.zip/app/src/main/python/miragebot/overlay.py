"""Overlay de diagnóstico: mostra o que o bot enxerga e decide (nome, posição, confiança, estado)."""
from __future__ import annotations
import cv2
import numpy as np

from .fsm import State
from .pipeline import HuntBot

COLORS = {"PROCURANDO": (200, 200, 200), "ALVO_SELECIONADO": (0, 215, 255), "ATACANDO": (0, 255, 0),
          "ALVO_TEMPORARIAMENTE_PERDIDO": (0, 140, 255), "VERIFICANDO_MORTE": (255, 0, 255), "LIBERANDO_ALVO": (255, 255, 0)}


def draw(bot: HuntBot, bgr: np.ndarray, scale: float = 0.5) -> np.ndarray:
    img = cv2.resize(bgr, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    obs, fsm = bot.last_obs, bot.fsm
    if obs is None:
        return img
    S = lambda v: int(v * scale)
    for d in obs.detections:
        x, y, w, h = d.box
        if d.name:
            cv2.rectangle(img, (S(x), S(y)), (S(x + w), S(y + h)), (0, 255, 0), 1)
            cv2.circle(img, (S(d.body[0]), S(d.body[1])), 3, (0, 255, 0), -1)
            fill = f" hp={d.bar_fill:.0%}" if d.bar_fill is not None else ""
            cv2.putText(img, f"{d.name} {d.confidence:.2f}{fill}", (S(x), S(y) - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 0), 1, cv2.LINE_AA)
        elif sum(ch.isalpha() for ch in d.raw) >= 3:
            cv2.rectangle(img, (S(x), S(y)), (S(x + w), S(y + h)), (150, 150, 150), 1)
            cv2.putText(img, f"x {d.raw[:18]}", (S(x), S(y) - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (150, 150, 150), 1, cv2.LINE_AA)
    for f in obs.frames:
        r = S(obs.tile / 2)
        cv2.rectangle(img, (S(f.center[0]) - r, S(f.center[1]) - r), (S(f.center[0]) + r, S(f.center[1]) + r), (255, 0, 255), 2)
    trk = fsm.track
    col = COLORS.get(fsm.state.value, (255, 255, 255))
    if trk is not None:
        c = (S(trk.pos[0]), S(trk.pos[1]))
        cv2.circle(img, c, S(obs.tile * 0.6), col, 2)
        cv2.putText(img, f"#{trk.serial} {trk.name}", (c[0] - 30, c[1] + S(obs.tile * 0.75)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1, cv2.LINE_AA)
    cv2.rectangle(img, (0, 0), (img.shape[1], 26), (0, 0, 0), -1)
    p = "RETRATO:ON" if obs.portrait_active else "retrato:off"
    cv2.putText(img, f"t={obs.t:5.1f}s  {fsm.state.value}  {p}  cam=({obs.shift[0]:+.0f},{obs.shift[1]:+.0f})"
                      f"  mortes={fsm.stats['mortes']} trocas={fsm.stats['trocas']}", (8, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.55, col, 1, cv2.LINE_AA)
    return img
