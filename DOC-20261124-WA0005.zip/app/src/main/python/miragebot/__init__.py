"""Mirage Hunter — bot de caça com OCR + HSV + rastreamento visual + máquina de estados."""
__version__ = "0.1.0"
