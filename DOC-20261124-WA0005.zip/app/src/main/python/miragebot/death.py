"""Confirmação de morte. REGRA: ausência de leitura (OCR falhou, oclusão, interface na frente) NUNCA basta.
É preciso um sinal POSITIVO do jogo (retrato do alvo apagado e moldura sumida) + o nome/sprite sumido de
forma PERSISTENTE, com a percepção saudável e o local visível. Barra zerada ou sprite trocado (corpo)
reduzem o tempo de persistência exigido."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .config import FsmConfig


@dataclass
class Verdict:
    status: str                                  # alive | pending | confirmed | blind
    persistence: float = 0.0
    needed: float = 0.0
    reasons: List[str] = field(default_factory=list)
    evidence: Dict[str, object] = field(default_factory=dict)


class DeathVerifier:
    GAME_CLEAR_MIN = 0.40     # retrato apagado e sem moldura por pelo menos isto

    def __init__(self, cfg: FsmConfig):
        self.c = cfg
        self.reset()

    def reset(self) -> None:
        self.absent_since: Optional[float] = None
        self.clear_since: Optional[float] = None
        self.blind_events = 0

    def update(self, t: float, *, seen_alive: bool, portrait_active: bool, frame_present: bool,
               perception_ok: bool, blind: bool, recent_min_fill: Optional[float],
               probe_diff: float) -> Verdict:
        if seen_alive:
            self.reset()
            return Verdict("alive", reasons=["alvo visto vivo"])
        if not perception_ok or blind:
            # não dá para ver: zera os cronômetros (exige nova janela completa de evidência)
            self.absent_since = None
            self.clear_since = None
            self.blind_events += 1
            why = "percepção instável (HUD/frame inválido)" if not perception_ok else "posição do alvo sob a interface/fora da tela"
            return Verdict("blind", reasons=[why])
        if self.absent_since is None:
            self.absent_since = t
        bar_low = recent_min_fill is not None and recent_min_fill <= self.c.death_low_bar
        # sinal positivo do jogo: moldura sumiu E (retrato apagou OU a vida estava baixa e o retrato só "mudou de cara")
        game_clear = (not frame_present) and ((not portrait_active) or bar_low)
        if game_clear:
            if self.clear_since is None:
                self.clear_since = t
        else:
            self.clear_since = None

        absent_for = t - self.absent_since
        clear_for = (t - self.clear_since) if self.clear_since is not None else 0.0
        corpse = probe_diff >= self.c.corpse_diff_threshold
        strong = bar_low or corpse
        needed = self.c.death_confirm_strong_s if strong else self.c.death_confirm_s
        persistence = min(absent_for, clear_for)

        reasons = [f"nome/sprite do alvo ausente há {absent_for:.1f}s"]
        reasons.append((f"retrato apagado e sem moldura há {clear_for:.1f}s" if not portrait_active else
                        f"moldura de seleção sumiu há {clear_for:.1f}s (retrato ainda aceso, mas a vida estava baixa)") if game_clear
                       else "retrato/moldura AINDA presentes (o jogo mantém a seleção)")
        if bar_low:
            reasons.append(f"barra de vida ≤{self.c.death_low_bar:.0%} antes de sumir")
        if corpse:
            reasons.append(f"sprite no local mudou (diff {probe_diff:.2f}, compatível com corpo)")
        ev = {"absent_for": round(absent_for, 2), "clear_for": round(clear_for, 2), "bar_low": bar_low,
              "corpse_like": corpse, "needed_s": needed}
        if game_clear and clear_for >= self.GAME_CLEAR_MIN and persistence >= needed:
            return Verdict("confirmed", persistence, needed, reasons, ev)
        return Verdict("pending", persistence, needed, reasons, ev)
