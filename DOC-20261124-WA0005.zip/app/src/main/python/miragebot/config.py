"""Configuração central. Tudo que é limiar/tempo/cor fica aqui (nada "mágico" espalhado no código)."""
from __future__ import annotations
import json
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple


@dataclass
class TargetSpec:
    """Um monstro permitido. A cor do nome é um INTERVALO HSV (não um RGB exato)."""
    name: str
    hue: Tuple[int, int] = (50, 70)      # OpenCV: H em 0..179 (verde puro ≈ 60)
    min_sat: int = 235
    min_val: int = 90
    priority: int = 0                    # maior = preferido quando há empate de distância
    enabled: bool = True


@dataclass
class VisionConfig:
    ref_tile_px: float = 111.0           # tamanho de 1 SQM na resolução de referência (2688x1216)
    name_h: Tuple[float, float] = (14.0, 32.0)      # altura da linha de nome (px de referência)
    name_w: Tuple[float, float] = (22.0, 420.0)
    min_ink_ratio: float = 0.14
    close_kernel_w: float = 13.0
    ocr_scale: int = 3
    body_offset_tiles: float = 0.72      # do rodapé do nome ao centro do sprite
    # aceitação do nome
    min_name_similarity: float = 0.80
    min_name_margin: float = 0.12        # distância para o 2º colocado (evita Spider × Raging Spider)
    min_color_score: float = 0.60
    min_confidence: float = 0.60
    width_tolerance: float = 0.22        # tolerância da largura aprendida por nome
    # moldura de seleção / retrato
    portrait_min_ratio: float = 0.08
    frame_min_score: float = 0.55
    frame_thickness: float = 8.0
    # movimento de cena
    motion_downscale: int = 8
    motion_min_response: float = 0.12


@dataclass
class TrackingConfig:
    base_radius_tiles: float = 0.9
    growth_tiles_per_s: float = 0.6
    max_radius_tiles: float = 4.0
    max_cost: float = 0.95
    velocity_decay_per_s: float = 2.0    # a velocidade estimada decai durante oclusão


@dataclass
class FsmConfig:
    # busca
    max_range_tiles: float = 7.0
    min_pick_confidence: float = 0.70
    post_release_delay_s: float = 0.40
    reject_log_interval_s: float = 1.5
    adopt_external_selection: bool = True
    # seleção
    select_confirm_timeout_s: float = 1.6
    max_select_retries: int = 3
    blacklist_s: float = 6.0
    # ataque / perda
    lost_after_s: float = 0.45
    reselect_after_s: float = 0.8        # retrato apagado com o alvo vivo e visível
    lost_alarm_s: float = 8.0
    recover_timeout_s: float = 10.0      # só vale com o retrato apagado (o jogo já soltou o alvo)
    no_damage_alarm_s: float = 6.0
    # morte
    death_confirm_s: float = 1.2         # persistência exigida (evidência fraca)
    death_confirm_strong_s: float = 0.6  # persistência exigida com barra zerada/corpo
    death_low_bar: float = 0.12
    death_verify_timeout_s: float = 5.0
    corpse_diff_threshold: float = 0.22


@dataclass
class IoConfig:
    min_retap_s: float = 0.9
    tap_lease_s: float = 0.35
    max_taps_per_target: int = 6
    dup_radius_tiles: float = 0.3


@dataclass
class Config:
    targets: List[TargetSpec] = field(default_factory=list)
    vision: VisionConfig = field(default_factory=VisionConfig)
    tracking: TrackingConfig = field(default_factory=TrackingConfig)
    fsm: FsmConfig = field(default_factory=FsmConfig)
    io: IoConfig = field(default_factory=IoConfig)

    # ---- JSON ----
    def to_json(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(asdict(self), f, ensure_ascii=False, indent=2)

    @staticmethod
    def from_json(path: str) -> "Config":
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        def mk(cls, data):
            data = dict(data or {})
            for k, v in list(data.items()):
                if isinstance(v, list) and k in ("hue", "name_h", "name_w"):
                    data[k] = tuple(v)
            return cls(**data)
        return Config(
            targets=[mk(TargetSpec, t) for t in d.get("targets", [])],
            vision=mk(VisionConfig, d.get("vision")),
            tracking=mk(TrackingConfig, d.get("tracking")),
            fsm=mk(FsmConfig, d.get("fsm")),
            io=mk(IoConfig, d.get("io")),
        )

    @staticmethod
    def default() -> "Config":
        names = ["Spider", "Raging Spider", "Elite Spider", "Imp", "Elite Imp",
                 "Frozen Imp", "Troll", "Raging Troll"]
        return Config(targets=[TargetSpec(n) for n in names])
