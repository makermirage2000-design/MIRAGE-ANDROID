"""Pipeline por frame:  imagem → percepção (HSV+OCR, seleção, movimento) → Observation → máquina de estados."""
from __future__ import annotations
import time
from typing import List, Optional, Tuple

import cv2
import numpy as np

from .config import Config
from .diagnostics import Diagnostics
from .fsm import TargetManager
from .geometry import Layout
from .io import Actuator, CommandGate
from .motion import SceneMotion
from .names import NameFinder, patch
from .selection import FrameHit, Portrait, SelectionReader
from .types import Decision, Observation


class HuntBot:
    def __init__(self, cfg: Config, actuator: Actuator, diag: Diagnostics, engine=None):
        self.cfg, self.diag = cfg, diag
        self.finder = NameFinder(cfg, engine)
        self.sel = SelectionReader(cfg)
        self.motion = SceneMotion(cfg)
        self.gate = CommandGate(actuator, cfg.io, diag)
        self.fsm = TargetManager(cfg, self.gate, diag)
        self.last_obs: Optional[Observation] = None
        self.last_portrait: Optional[Portrait] = None

    def perceive(self, bgr: np.ndarray, t: float) -> Observation:
        h, w = bgr.shape[:2]
        lay = Layout(w, h)
        tile = lay.tile(self.cfg.vision.ref_tile_px)
        tm = time.perf_counter()
        hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
        self.diag.timing("hsv", (time.perf_counter() - tm) * 1000); tm = time.perf_counter()

        dx, dy, ok = self.motion.update(bgr, lay)
        self.diag.timing("movimento", (time.perf_counter() - tm) * 1000); tm = time.perf_counter()

        wp0 = self.fsm.watch_pos()
        dets = self.finder.find(bgr, hsv, lay, focus=wp0)
        if wp0 is not None:
            for dd in self.finder.find_damaged(bgr, hsv, lay, wp0):
                if all(np.hypot(dd.body[0] - o.body[0], dd.body[1] - o.body[1]) > 0.35 * tile for o in dets if o.name):
                    dets.append(dd)
        self.diag.timing("nomes(HSV+OCR)", (time.perf_counter() - tm) * 1000); tm = time.perf_counter()

        portrait = self.sel.portrait(hsv, lay)
        frames: List[FrameHit] = []

        def add(fh: Optional[FrameHit]):
            if fh is None or (fh.kind == "dark" and not portrait.active):   # moldura escura só vale com o retrato aceso
                return
            if all(np.hypot(fh.center[0] - o.center[0], fh.center[1] - o.center[1]) > 0.4 * tile for o in frames):
                frames.append(fh)

        for d in dets:
            if d.name and d.bar_present:
                add(self.sel.frame_near(bgr, hsv, d.body, 0.45 * tile, lay))
        wp = self.fsm.watch_pos()
        probe = None
        if wp is not None:
            add(self.sel.frame_near(bgr, hsv, wp, 0.9 * tile, lay))
            probe = patch(bgr, wp, 0.8 * tile)
        self.diag.timing("seleção", (time.perf_counter() - tm) * 1000)

        x0, y0, x1, y1 = lay.hud_bars
        roi = hsv[y0:y1, x0:x1]
        hud_ok = float(((roi[..., 1] > 150) & (roi[..., 2] > 100)).mean()) >= 0.05 and float(bgr.mean()) > 8
        obs = Observation(t=t, detections=dets, portrait_active=portrait.active, portrait_sig=(portrait.hue, portrait.ratio), frames=frames, shift=(dx, dy),
                          shift_ok=ok, perception_ok=hud_ok, player=lay.player, tile=tile,
                          blind_rects=lay.excluded, frame_size=(w, h), probe_thumb=probe)
        self.last_obs, self.last_portrait = obs, portrait
        return obs

    def process(self, bgr: np.ndarray, t: float) -> Decision:
        obs = self.perceive(bgr, t)
        tm = time.perf_counter()
        dec = self.fsm.step(obs)
        self.diag.timing("máquina de estados", (time.perf_counter() - tm) * 1000)
        return dec
