"""Geometria independente de resolução. Tudo é definido em 2688x1216 e escalado."""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple

REF_W, REF_H = 2688, 1216
Rect = Tuple[int, int, int, int]  # x0, y0, x1, y1


@dataclass
class Layout:
    w: int
    h: int

    @property
    def s(self) -> float:            # escala dos tamanhos (o jogo escala pela altura)
        return self.h / REF_H

    @property
    def sx(self) -> float:
        return self.w / REF_W

    def rect(self, x0, y0, x1, y1) -> Rect:
        return (int(x0 * self.sx), int(y0 * self.s), int(x1 * self.sx), int(y1 * self.s))

    # --- regiões fixas da interface (valores em 2688x1216) ---
    @property
    def excluded(self) -> List[Rect]:
        r = self.rect
        return [r(0, 0, 830, 180), r(0, 180, 180, 420), r(0, 0, 40, 1216),
                r(1900, 0, 2688, 180), r(2150, 640, 2688, 1216),
                r(60, 720, 545, 1216), r(540, 1120, 900, 1216)]

    @property
    def portrait(self) -> Rect:      # disco do alvo selecionado (esquerda do ícone de chat)
        return self.rect(1925, 0, 2125, 170)

    @property
    def hud_bars(self) -> Rect:
        return self.rect(40, 0, 830, 100)

    @property
    def player(self) -> Tuple[float, float]:
        return (self.w * 0.497, self.h * 0.501)

    def tile(self, ref_tile: float) -> float:
        return ref_tile * self.s

    def in_excluded(self, x: float, y: float, margin: float = 0.0) -> bool:
        for x0, y0, x1, y1 in self.excluded:
            if x0 - margin <= x <= x1 + margin and y0 - margin <= y <= y1 + margin:
                return True
        return False
