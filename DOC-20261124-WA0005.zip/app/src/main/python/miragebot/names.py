"""Leitura de nomes: HSV (onde está o texto) + OCR (o que diz) + HSV (a cor confere?).

Pipeline por linha de nome:
  1. máscara HSV por intervalo de matiz  -> acha linhas de texto (sem depender de RGB exato)
  2. OCR (Tesseract) só na máscara binária do texto, com memória por pixel (a fonte é bitmap:
     o mesmo nome produz os mesmos pixels, então o resultado vira cache determinístico)
  3. casamento difuso com a lista de alvos permitidos (com margem para o 2º colocado)
  4. conferência de cor + largura aprendida + barra de vida logo abaixo
"""
from __future__ import annotations
import re, hashlib
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

from .config import Config, TargetSpec
from .geometry import Layout


def norm(s: str) -> str:
    return re.sub(r"[^a-z]", "", s.lower())


@dataclass
class NameDetection:
    box: Tuple[int, int, int, int]            # x, y, w, h da linha de texto (px nativos)
    raw: str = ""
    name: Optional[str] = None                # nome canônico PERMITIDO (None = rejeitado)
    ocr_conf: float = 0.0
    similarity: float = 0.0
    margin: float = 0.0
    runner_up: Optional[str] = None
    hue: float = -1.0
    color_score: float = 0.0
    confidence: float = 0.0
    bar_fill: Optional[float] = None          # 0..1 relativo à maior barra vista; None = sem barra
    bar_present: bool = False
    bar_px: float = 0.0                       # largura do preenchimento (px de referência)
    body: Tuple[float, float] = (0.0, 0.0)    # centro estimado do sprite (onde tocar)
    thumb: Optional[np.ndarray] = None        # miniatura 24x24 do sprite (aparência)
    reason: str = ""                          # por que foi aceito/rejeitado (diagnóstico)

    @property
    def accepted(self) -> bool:
        return self.name is not None

    @property
    def center(self) -> Tuple[float, float]:
        x, y, w, h = self.box
        return (x + w / 2, y + h / 2)


class TesseractEngine:
    """OCR de uma máscara binária (texto = 255). Devolve (texto, confiança 0..1)."""
    def __init__(self, scale: int = 3):
        import pytesseract
        self.pt = pytesseract
        self.scale = scale
        self.cfg = ("--psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                    "abcdefghijklmnopqrstuvwxyz -c preserve_interword_spaces=1")

    def read(self, mask: np.ndarray) -> Tuple[str, float]:
        m = cv2.resize(mask, None, fx=self.scale, fy=self.scale, interpolation=cv2.INTER_NEAREST)
        m = cv2.copyMakeBorder(255 - m, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
        d = self.pt.image_to_data(m, config=self.cfg, output_type=self.pt.Output.DICT)
        words = [(w, c) for w, c in zip(d["text"], d["conf"]) if w.strip()]
        if not words:
            return "", 0.0
        txt = " ".join(w for w, _ in words)
        confs = [max(0.0, float(c)) for _, c in words]
        return txt, sum(confs) / len(confs) / 100.0


class NameFinder:
    def __init__(self, cfg: Config, engine=None):
        self.cfg = cfg
        self.v = cfg.vision
        self.engine = engine or TesseractEngine(self.v.ocr_scale)
        self.specs: Dict[str, TargetSpec] = {norm(t.name): t for t in cfg.targets if t.enabled}
        self.memo: Dict[str, Tuple[str, float]] = {}
        self.width_ref: Dict[str, float] = {}     # largura aprendida por nome (em tiles)
        self.bar_ref: Dict[str, float] = {}       # maior barra vista, POR nome
        self.stats = {"ocr_calls": 0, "ocr_hits": 0}

    # ------------------------------------------------------------------ máscaras HSV
    def color_mask(self, hsv: np.ndarray) -> np.ndarray:
        mask = np.zeros(hsv.shape[:2], np.uint8)
        seen = set()
        for sp in self.specs.values():
            key = (sp.hue, sp.min_sat, sp.min_val)
            if key in seen:
                continue
            seen.add(key)
            lo = np.array([sp.hue[0], sp.min_sat, sp.min_val], np.uint8)
            hi = np.array([sp.hue[1], 255, 255], np.uint8)
            mask |= cv2.inRange(hsv, lo, hi)
        return mask

    # ------------------------------------------------------------------ API principal
    def find(self, bgr: np.ndarray, hsv: np.ndarray, lay: Layout,
             focus: Optional[Tuple[float, float]] = None) -> List[NameDetection]:
        """`focus` = posição do alvo rastreado: ali o OCR roda mesmo sem barra (alvo quase morto)."""
        s = lay.s
        mask = self.color_mask(hsv)
        for x0, y0, x1, y1 in lay.excluded:
            mask[y0:y1, x0:x1] = 0
        # 1) palavras: letras próximas viram um bloco
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (max(3, int(9 * s)), 1))
        closed = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k)
        n, _, st, _ = cv2.connectedComponentsWithStats(closed, connectivity=8)
        words = []
        for i in range(1, n):
            x, y, w, h, _ = st[i]
            if self.v.name_h[0] * s <= h <= self.v.name_h[1] * s and w >= 12 * s:
                if int((mask[y:y + h, x:x + w] > 0).sum()) >= self.v.min_ink_ratio * w * h:
                    words.append((int(x), int(y), int(w), int(h)))
        words = [p for wd in words for p in self._split_blob(mask, wd, hsv, s)]
        # 2) linhas: palavras vizinhas (mesma altura, folga pequena) formam UM nome ("Elite Spider")
        lines = self._chain(words, hsv, s)
        out: List[NameDetection] = []
        tile = lay.tile(self.v.ref_tile_px)
        px, py = lay.player
        for (x, y, w, h) in lines:
            if not (self.v.name_w[0] * s <= w <= self.v.name_w[1] * s):
                continue
            det = NameDetection(box=(x, y, w, h))
            det.body = (x + w / 2, y + h + self.v.body_offset_tiles * tile)
            self._bar(det, hsv, lay)
            near_focus = focus is not None and np.hypot(det.body[0] - focus[0], det.body[1] - focus[1]) <= 1.5 * tile
            if not det.bar_present and not near_focus:
                det.reason = "sem barra de vida abaixo do texto (não é plaqueta de monstro) — OCR dispensado"
                self.stats["sem_barra"] = self.stats.get("sem_barra", 0) + 1
                out.append(det)
                continue
            self._read(det, bgr, hsv, mask, lay)
            if det.name and np.hypot(det.body[0] - px, det.body[1] - py) < 0.55 * tile:
                det.name, det.reason = None, "é o próprio personagem"
            if det.name:   # barra relativa à maior barra vista PARA ESTE NOME
                ref = max(self.bar_ref.get(det.name, 0.0), det.bar_px)
                self.bar_ref[det.name] = ref
                det.bar_fill = min(1.0, det.bar_px / ref) if ref > 0 and det.bar_present else None
            self._thumb(det, bgr, tile)
            out.append(det)
        return out

    # ------------------------------------------------------------------ nomes coloridos pela VIDA
    HP_BUCKETS = [((6, 34),), ((35, 49),), ((0, 5), (172, 180))]   # laranja/amarelo · amarelo-esverdeado · vermelho

    def find_damaged(self, bgr, hsv, lay: Layout, focus: Tuple[float, float]) -> List[NameDetection]:
        """No jogo a cor do nome (e da barra) acompanha a vida: verde → amarelo → laranja → vermelho.
        Perto do alvo rastreado procuramos também essas cores, senão o bot o perderia ao feri-lo.
        Aqui a barra pode estar quase vazia, então ela NÃO é exigida; o OCR precisa casar com um alvo permitido."""
        s = lay.s
        tile = lay.tile(self.v.ref_tile_px)
        x0, x1 = max(0, int(focus[0] - 1.9 * tile)), min(lay.w, int(focus[0] + 1.9 * tile))
        y0, y1 = max(0, int(focus[1] - 2.3 * tile)), min(lay.h, int(focus[1] + 1.0 * tile))
        if x1 - x0 < 50 or y1 - y0 < 50:
            return []
        win = hsv[y0:y1, x0:x1]
        out: List[NameDetection] = []
        for ranges in self.HP_BUCKETS:
            m = np.zeros(win.shape[:2], np.uint8)
            for lo, hi in ranges:
                m |= cv2.inRange(win, (lo, 235, 90), (hi, 255, 255))
            full = np.zeros(hsv.shape[:2], np.uint8)
            full[y0:y1, x0:x1] = m
            for ex0, ey0, ex1, ey1 in lay.excluded:
                full[ey0:ey1, ex0:ex1] = 0
            k = cv2.getStructuringElement(cv2.MORPH_RECT, (max(3, int(9 * s)), 1))
            closed = cv2.morphologyEx(full[y0:y1, x0:x1], cv2.MORPH_CLOSE, k)
            n, _, st, _ = cv2.connectedComponentsWithStats(closed, connectivity=8)
            words = []
            for i in range(1, n):
                x, y, w, h, _ = st[i]
                x += x0; y += y0
                if self.v.name_h[0] * s <= h <= self.v.name_h[1] * s and w >= 12 * s and \
                        int((full[y:y + h, x:x + w] > 0).sum()) >= self.v.min_ink_ratio * w * h:
                    words.append((int(x), int(y), int(w), int(h)))
            for (x, y, w, h) in self._chain(words, hsv, s):
                if not (self.v.name_w[0] * s <= w <= self.v.name_w[1] * s):
                    continue
                det = NameDetection(box=(x, y, w, h))
                det.body = (x + w / 2, y + h + self.v.body_offset_tiles * tile)
                self._read(det, bgr, hsv, full, lay, hue_free=True)
                if not det.name:
                    continue
                self._bar_hued(det, hsv, lay, ranges)
                # vida pela cor quando a barra é pequena demais para medir (hue 0=vazio ... 60=cheio)
                est = max(0.0, min(1.0, (det.hue if det.hue <= 90 else 0.0) / 60.0))
                if det.bar_present and self.bar_ref.get(det.name):
                    det.bar_fill = min(1.0, det.bar_px / self.bar_ref[det.name])
                else:
                    det.bar_fill = est
                det.reason += f" [nome colorido pela vida: matiz {det.hue:.0f} ≈ {est:.0%}]"
                self._thumb(det, bgr, tile)
                out.append(det)
        return out

    def _bar_hued(self, det, hsv, lay, ranges):
        x, y, w, h = det.box
        runs = self._bar_runs(hsv, x, x + w, y + h, lay.s, ranges)
        if runs:
            x0, x1 = max(runs, key=lambda r: r[1] - r[0])
            det.bar_px = (x1 - x0) / max(lay.s, 1e-6)
            det.bar_present = True

    def _split_blob(self, mask, wd, hsv, s):
        """Um bloco com 2+ barras de vida embaixo são 2+ nomes colados: corta nas maiores colunas vazias."""
        x, y, w, h = wd
        if w < 90 * s:
            return [wd]
        runs = self._bar_runs(hsv, x, x + w, y + h, s)
        if len(runs) < 2:
            return [wd]
        empty = ~(mask[y:y + h, x:x + w] > 0).any(axis=0)
        gaps, start = [], None
        for i, e in enumerate(list(empty) + [False]):
            if e and start is None: start = i
            if not e and start is not None:
                gaps.append((i - start, start, i)); start = None
        gaps = sorted([g for g in gaps if g[0] >= 10 * s], reverse=True)[:len(runs) - 1]   # só folgas de ENTRE nomes
        cuts = sorted((a + b) // 2 for _, a, b in gaps)
        edges, out = [0] + cuts + [w], []
        for a, b in zip(edges[:-1], edges[1:]):
            sub = mask[y:y + h, x + a:x + b] > 0
            if sub.any():
                cols = np.where(sub.any(axis=0))[0]
                out.append((x + a + int(cols[0]), y, int(cols[-1] - cols[0] + 1), h))
        return out or [wd]

    def _chain(self, words, hsv, s):
        """Agrupa palavras em nomes. Folga ≤ 20px junta ('Elite'+'Spider'); se houver 2+ barras de vida
        sob a cadeia, são 2+ monstros vizinhos e a cadeia é cortada na maior folga."""
        words = sorted(words, key=lambda b: b[0])
        chains = []
        for wd in words:
            best, best_gap = None, None
            for ch in chains:
                px, py, pw, ph = ch[-1]
                same_row = abs((wd[1] + wd[3] / 2) - (py + ph / 2)) <= 5 * s and abs(wd[3] - ph) <= 7 * s
                gap = wd[0] - (px + pw)
                if same_row and 0 <= gap <= 20 * s and (best_gap is None or gap < best_gap):
                    best, best_gap = ch, gap
            if best is None:
                chains.append([wd])
            else:
                best.append(wd)
        lines = []
        for ch in chains:
            parts = [ch]
            if len(ch) >= 2:
                x0 = min(b[0] for b in ch); x1 = max(b[0] + b[2] for b in ch)
                yb = max(b[1] + b[3] for b in ch)
                runs = self._bar_runs(hsv, x0, x1, yb, s)
                if len(runs) >= 2:
                    gaps = sorted(range(len(ch) - 1), key=lambda i: -(ch[i + 1][0] - (ch[i][0] + ch[i][2])))
                    cuts = sorted(gaps[:len(runs) - 1])
                    parts, a = [], 0
                    for c in cuts:
                        parts.append(ch[a:c + 1]); a = c + 1
                    parts.append(ch[a:])
            for p in parts:
                x0 = min(b[0] for b in p); y0 = min(b[1] for b in p)
                x1 = max(b[0] + b[2] for b in p); y1 = max(b[1] + b[3] for b in p)
                lines.append((x0, y0, x1 - x0, y1 - y0))
        return lines

    @staticmethod
    def _bar_runs(hsv, x0, x1, y_bottom, s, hue_ranges=None):
        """Preenchimentos de barra de vida abaixo do nome: retângulos finos, sólidos e coloridos.
        A faixa de busca é só a da barra (não pega o sprite, que começa ~20px abaixo do texto)."""
        ya, yb = y_bottom + int(2 * s), y_bottom + int(14 * s)
        xa, xb = max(0, x0 - int(4 * s)), x1 + int(4 * s)
        band = hsv[ya:yb, xa:xb]
        if band.size == 0:
            return []
        hh, ss, vv = band[..., 0], band[..., 1], band[..., 2]
        # cores da barra: verde / amarelo / vermelho puros. O matiz 37–51 (grama, folhagem) fica de fora.
        if hue_ranges is None:
            hue_ok = (hh <= 12) | ((hh >= 20) & (hh <= 36)) | ((hh >= 52) & (hh <= 68)) | (hh >= 168)
        else:
            hue_ok = np.zeros(hh.shape, bool)
            for lo, hi in hue_ranges:
                hue_ok |= (hh >= lo) & (hh <= hi)
        col = (hue_ok & (ss >= 200) & (vv >= 80)).astype(np.uint8) * 255
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (max(5, int(10 * s)), max(2, int(3 * s))))
        op = cv2.morphologyEx(col, cv2.MORPH_OPEN, k)
        n, _, st, _ = cv2.connectedComponentsWithStats(op, connectivity=8)
        runs = []
        for i in range(1, n):
            x, y, w, h, a = st[i]
            if 3 * s <= h <= 11 * s and w >= 10 * s and a >= 0.8 * w * h:
                runs.append((int(x + xa), int(x + xa + w)))
        return sorted(runs)

    # ------------------------------------------------------------------ OCR + casamento
    def _read(self, det: NameDetection, bgr, hsv, mask, lay: Layout, hue_free: bool = False) -> None:
        x, y, w, h = det.box
        pad = 2
        crop = mask[max(0, y - pad):y + h + pad, max(0, x - pad):x + w + pad]
        key = hashlib.sha1(crop.tobytes() + str(crop.shape).encode()).hexdigest()
        if key in self.memo:
            det.raw, det.ocr_conf = self.memo[key]
            self.stats["ocr_hits"] += 1
        else:
            det.raw, det.ocr_conf = self.engine.read(crop)
            self.memo[key] = (det.raw, det.ocr_conf)
            self.stats["ocr_calls"] += 1

        # matiz mediana do texto
        sub = hsv[y:y + h, x:x + w]
        mm = mask[y:y + h, x:x + w] > 0
        if mm.sum() > 0:
            det.hue = float(np.median(sub[..., 0][mm]))

        cand = norm(det.raw)
        if len(cand) < 2:
            det.reason = "OCR sem texto legível"
            return
        scored = sorted(((SequenceMatcher(None, cand, k).ratio(), k) for k in self.specs), reverse=True)
        best_s, best_k = scored[0]
        second_s = scored[1][0] if len(scored) > 1 else 0.0
        det.similarity, det.margin = best_s, best_s - second_s
        det.runner_up = self.specs[scored[1][1]].name if len(scored) > 1 else None
        spec = self.specs[best_k]

        if best_s < self.v.min_name_similarity:
            det.reason = f"nome fora da lista (melhor '{spec.name}' {best_s:.2f}, OCR '{det.raw}')"
            return
        if det.margin < self.v.min_name_margin and best_s < 0.999:
            det.reason = (f"ambíguo entre '{spec.name}' e '{det.runner_up}' "
                          f"(margem {det.margin:.2f}, OCR '{det.raw}')")
            return
        # --- HSV: a cor do texto confere com a do alvo? ---
        det.color_score = 1.0 if hue_free else self._color_score(sub, mask[y:y + h, x:x + w] > 0, spec)
        if det.color_score < self.v.min_color_score:
            det.reason = f"cor incompatível com '{spec.name}' (HSV {det.color_score:.2f}, matiz {det.hue:.0f})"
            return
        # --- largura aprendida (separa 'Spider' de um 'Elite Spider' cortado) ---
        tile = lay.tile(self.v.ref_tile_px)
        wt = w / tile
        ref = self.width_ref.get(best_k)
        if ref and abs(wt - ref) / ref > self.v.width_tolerance:
            det.reason = f"largura {wt:.2f}t incompatível com '{spec.name}' (ref {ref:.2f}t)"
            return
        det.confidence = 0.45 * best_s + 0.25 * det.ocr_conf + 0.30 * det.color_score
        if det.confidence < self.v.min_confidence:
            det.reason = f"confiança baixa {det.confidence:.2f} para '{spec.name}'"
            return
        det.name = spec.name
        det.reason = f"aceito: OCR '{det.raw}'→'{spec.name}' sim={best_s:.2f} cor={det.color_score:.2f}"
        if det.confidence >= 0.85:   # aprende a largura só com leituras confiáveis
            self.width_ref[best_k] = wt if best_k not in self.width_ref else 0.9 * self.width_ref[best_k] + 0.1 * wt

    @staticmethod
    def _color_score(sub_hsv: np.ndarray, ink: np.ndarray, spec: TargetSpec) -> float:
        """Fração dos pixels de TINTA do texto cujo matiz está no intervalo HSV do alvo."""
        n = int(ink.sum())
        if n == 0:
            return 0.0
        h = sub_hsv[..., 0]
        return float((ink & (h >= spec.hue[0]) & (h <= spec.hue[1])).sum()) / n

    # ------------------------------------------------------------------ barra de vida
    def _bar(self, det: NameDetection, hsv: np.ndarray, lay: Layout) -> None:
        x, y, w, h = det.box
        s = lay.s
        runs = self._bar_runs(hsv, x, x + w, y + h, s)
        if runs:
            x0, x1 = max(runs, key=lambda r: r[1] - r[0])
            det.bar_px = (x1 - x0) / max(s, 1e-6)
            det.bar_present = True

    def _thumb(self, det: NameDetection, bgr: np.ndarray, tile: float) -> None:
        det.thumb = patch(bgr, det.body, tile * 0.8)


def patch(bgr: np.ndarray, center: Tuple[float, float], size: float) -> Optional[np.ndarray]:
    cx, cy = center
    r = int(size / 2)
    x0, y0, x1, y1 = int(cx) - r, int(cy) - r, int(cx) + r, int(cy) + r
    H, W = bgr.shape[:2]
    if x0 < 0 or y0 < 0 or x1 > W or y1 > H or r < 4:
        return None
    return cv2.resize(bgr[y0:y1, x0:x1], (24, 24), interpolation=cv2.INTER_AREA)


def thumb_diff(a: Optional[np.ndarray], b: Optional[np.ndarray]) -> float:
    """Diferença média normalizada 0..1 entre miniaturas (None → 0)."""
    if a is None or b is None:
        return 0.0
    return float(np.mean(np.abs(a.astype(np.int16) - b.astype(np.int16)))) / 255.0
