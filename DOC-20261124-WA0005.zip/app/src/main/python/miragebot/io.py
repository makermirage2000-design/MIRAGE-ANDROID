"""Saída de comandos. TODO toque passa pelo CommandGate: sem duplicados, sem toque "velho"
(de um alvo que já foi liberado), com limite por alvo."""
from __future__ import annotations
import subprocess
from abc import ABC, abstractmethod
from typing import List, Optional, Tuple

from .config import IoConfig
from .diagnostics import Diagnostics


class Actuator(ABC):
    @abstractmethod
    def tap(self, x: float, y: float) -> bool: ...


class DryRunActuator(Actuator):
    """Não envia nada; só registra (validação offline em vídeo)."""
    def __init__(self):
        self.taps: List[Tuple[float, float]] = []

    def tap(self, x, y):
        self.taps.append((x, y)); return True


class AdbActuator(Actuator):
    """Toque via ADB (PC → celular). Coordenadas em pixels da tela do aparelho."""
    def __init__(self, serial: Optional[str] = None, scale: float = 1.0):
        self.base = ["adb"] + (["-s", serial] if serial else []) + ["shell", "input", "tap"]
        self.scale = scale

    def tap(self, x, y):
        r = subprocess.run(self.base + [str(int(x * self.scale)), str(int(y * self.scale))],
                           capture_output=True, timeout=3)
        return r.returncode == 0


class CommandGate:
    def __init__(self, actuator: Actuator, cfg: IoConfig, diag: Diagnostics):
        self.act, self.c, self.diag = actuator, cfg, diag
        self.last_tap_t = -1e9
        self.last_xy: Optional[Tuple[float, float]] = None
        self.lease_until = -1e9
        self.per_serial = {}
        self.sent = 0
        self.blocked = {"stale": 0, "lease": 0, "interval": 0, "limit": 0, "dup": 0}

    def release(self, serial: int) -> None:
        self.lease_until = -1e9
        self.per_serial.pop(serial, None)

    def tap(self, t: float, serial: int, current_serial: Optional[int], x: float, y: float,
            tile: float, reason: str, state: str = "") -> bool:
        why = None
        if current_serial is None or serial != current_serial:
            why = "stale"          # comando de um alvo que não é mais o atual
        elif t < self.lease_until:
            why = "lease"          # gesto anterior ainda em andamento
        elif t - self.last_tap_t < self.c.min_retap_s:
            why = "interval"
        elif self.per_serial.get(serial, 0) >= self.c.max_taps_per_target:
            why = "limit"
        elif self.last_xy and t - self.last_tap_t < self.c.min_retap_s and \
                ((x - self.last_xy[0]) ** 2 + (y - self.last_xy[1]) ** 2) ** 0.5 < self.c.dup_radius_tiles * tile:
            why = "dup"
        if why:
            self.blocked[why] += 1
            self.diag.log_limited(f"gate-{why}-{serial}", 1.0, t, "toque_bloqueado",
                                  f"toque NÃO enviado ({why}): {reason}", state, serial=serial)
            return False
        ok = self.act.tap(x, y)
        self.last_tap_t, self.last_xy = t, (x, y)
        self.lease_until = t + self.c.tap_lease_s
        self.per_serial[serial] = self.per_serial.get(serial, 0) + 1
        self.sent += 1
        self.diag.log(t, "toque", f"toque enviado em ({x:.0f},{y:.0f}): {reason}", state, serial=serial, ok=ok)
        return ok
