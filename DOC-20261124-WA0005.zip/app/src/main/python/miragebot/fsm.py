"""Gerenciador de alvos — máquina de estados.

    PROCURANDO ──► ALVO_SELECIONADO ──► ATACANDO ◄──► ALVO_TEMPORARIAMENTE_PERDIDO
                                           │                    │
                                           └──► VERIFICANDO_MORTE ◄┘
                                                      │
                                              LIBERANDO_ALVO ──► PROCURANDO

REGRA PRINCIPAL (invariante): só existe UM caminho para um novo alvo — PROCURANDO — e só se chega nele
passando por LIBERANDO_ALVO. Enquanto há um alvo (qualquer estado ≠ PROCURANDO/LIBERANDO) nenhum candidato
é sequer avaliado. Saídas de LIBERANDO_ALVO, todas registradas com motivo:
  • morte_confirmada          — evidência visual persistente (ver death.py)
  • selecao_recusada          — o jogo nunca aceitou a seleção do monstro (esgotou as tentativas)
  • perdido_nao_confirmado    — o PRÓPRIO JOGO soltou o alvo (retrato apagado) e a morte não pôde ser provada
"""
from __future__ import annotations
import math
from collections import Counter
from enum import Enum
from typing import List, Optional, Tuple

from .config import Config
from .death import DeathVerifier, Verdict
from .diagnostics import Diagnostics
from .io import CommandGate
from .names import NameDetection, thumb_diff
from .tracker import Match, TargetTracker, Track
from .types import Decision, Observation, TapCommand


class State(str, Enum):
    PROCURANDO = "PROCURANDO"
    ALVO_SELECIONADO = "ALVO_SELECIONADO"
    ATACANDO = "ATACANDO"
    ALVO_TEMPORARIAMENTE_PERDIDO = "ALVO_TEMPORARIAMENTE_PERDIDO"
    VERIFICANDO_MORTE = "VERIFICANDO_MORTE"
    LIBERANDO_ALVO = "LIBERANDO_ALVO"


HAS_TARGET = (State.ALVO_SELECIONADO, State.ATACANDO, State.ALVO_TEMPORARIAMENTE_PERDIDO, State.VERIFICANDO_MORTE)


class TargetManager:
    def __init__(self, cfg: Config, gate: CommandGate, diag: Diagnostics):
        self.cfg, self.c, self.gate, self.diag = cfg, cfg.fsm, gate, diag
        self.tracker = TargetTracker(cfg)
        self.verifier = DeathVerifier(self.c)
        self.priority = {t.name: t.priority for t in cfg.targets}
        self.state = State.PROCURANDO
        self.track: Optional[Track] = None
        self._serial = 0
        self.blacklist: List[list] = []            # [x, y, until, raio_px]
        self.next_search_at = 0.0
        self.sel_started = 0.0
        self.verify_started = 0.0
        self.inactive_since: Optional[float] = None
        self.unident_since: Optional[float] = None
        self.reselect = False
        self.stale_sig: Optional[Tuple[float, float]] = None   # retrato que continuou aceso após uma morte
        self.last_release_reason: Optional[str] = None
        self.last_release_serial: Optional[int] = None
        self.stats: Counter = Counter()
        self.history: List[Tuple[float, str, str]] = []
        self._sent: List[TapCommand] = []
        self._note = ""

    # ------------------------------------------------------------------ utilidades
    @property
    def has_target(self) -> bool:
        return self.track is not None and self.state in HAS_TARGET

    def watch_pos(self) -> Optional[Tuple[float, float]]:
        """Onde o pipeline deve olhar com mais cuidado (moldura/miniatura) no próximo frame."""
        return self.track.pos if self.track is not None else None

    def _goto(self, new: State, reason: str, t: float, **data) -> None:
        old = self.state
        self.state = new
        self._note = reason
        self.history.append((t, new.value, reason))
        self.diag.log(t, "estado", f"{old.value} → {new.value}: {reason}", new.value, **data)

    def _tap_track(self, obs: Observation, reason: str) -> bool:
        trk = self.track
        if trk is None:
            return False
        ok = self.gate.tap(obs.t, trk.serial, trk.serial, trk.pos[0], trk.pos[1], obs.tile, reason, self.state.value)
        if ok:
            trk.taps += 1
            self._sent.append(TapCommand(trk.pos[0], trk.pos[1], trk.serial, reason))
        return ok

    def _match(self, obs: Observation) -> Match:
        m = self.tracker.match(self.track, obs)
        self.tracker.apply(self.track, m, obs)
        return m

    def _portrait_fresh(self, obs: Observation) -> bool:
        """Depois de uma morte o disco do retrato FICA aceso (visto em vídeo real). Ele só prova uma
        NOVA seleção se mudou de aparência em relação ao que ficou aceso."""
        if self.stale_sig is None:
            return True
        return abs(obs.portrait_sig[0] - self.stale_sig[0]) > 4 or abs(obs.portrait_sig[1] - self.stale_sig[1]) > 0.05

    def _low_hp(self, trk: Track, t: float) -> bool:
        """A vida do alvo estava baixa (barra ≤ limite OU nome vermelho) pouco antes de ele sumir?"""
        v = trk.recent_min_fill(t, 6.0)
        return v is not None and v <= self.c.death_low_bar

    def _resume(self, obs: Observation, m: Match, why: str) -> None:
        """Alvo visto de novo: volta a atacar (se o jogo ainda o mantém) ou reseleciona o MESMO alvo."""
        if obs.portrait_active or m.frame_on_target:
            self._goto(State.ATACANDO, why, obs.t)
        else:
            self.reselect = True
            self.sel_started = obs.t
            self._goto(State.ALVO_SELECIONADO, why + " — retrato apagado: reselecionando o MESMO alvo", obs.t)
            self._tap_track(obs, "reselecionar o mesmo alvo (retrato apagado, alvo visível)")

    # ------------------------------------------------------------------ passo principal
    def step(self, obs: Observation) -> Decision:
        self._sent = []
        self._note = ""
        for b in self.blacklist:                       # quarentenas acompanham a câmera
            if obs.shift_ok:
                b[0] += obs.shift[0]; b[1] += obs.shift[1]
        self.blacklist = [b for b in self.blacklist if b[2] > obs.t]
        if self.track is not None:
            self.tracker.advance(self.track, obs)
        {
            State.PROCURANDO: self._search,
            State.ALVO_SELECIONADO: self._selected,
            State.ATACANDO: self._attacking,
            State.ALVO_TEMPORARIAMENTE_PERDIDO: self._lost,
            State.VERIFICANDO_MORTE: self._verify,
            State.LIBERANDO_ALVO: self._finish_release,
        }[self.state](obs)
        return Decision(self.state.value, list(self._sent), self._note)

    # ------------------------------------------------------------------ PROCURANDO
    def _search(self, obs: Observation) -> None:
        t, tile = obs.t, obs.tile
        if not obs.portrait_active:
            self.stale_sig = None
        if t < self.next_search_at or self.track is not None:
            return
        accepted = [d for d in obs.detections if d.name]

        # o jogo já tem alguém selecionado (o jogador tocou, ou toque anterior): ADOTA em vez de trocar
        live = obs.portrait_active and self._portrait_fresh(obs)     # retrato velho (pós-morte) não conta como seleção
        if self.c.adopt_external_selection and live:
            best = None
            for d in accepted:
                f = [fr for fr in obs.frames if math.hypot(fr.center[0] - d.body[0], fr.center[1] - d.body[1]) <= 0.7 * tile]
                if f and (best is None or f[0].score > best[1].score):
                    best = (d, f[0])
            if best:
                self.unident_since = None
                self._start_target(obs, best[0], origin="externo",
                                   why=f"seleção já feita no jogo (retrato ativo + moldura {best[1].kind}, score {best[1].score:.2f})")
                self.track.selected_confirmed = True
                self.track.engaged_at = t
                self._goto(State.ATACANDO, "seleção externa adotada: nenhum toque enviado", t)
                return
            if self.unident_since is None:
                self.unident_since = t
            if t - self.unident_since < 3.0:
                self.diag.log_limited("unident", 1.5, t, "aguardando",
                                      "retrato ativo, mas a moldura não está em nenhum nome lido — não procuro outro para não trocar o alvo do jogo",
                                      self.state.value)
                return
        else:
            self.unident_since = None

        cands: List[Tuple[float, NameDetection, float]] = []
        for d in obs.detections:
            reason = None
            dist = math.hypot(d.body[0] - obs.player[0], d.body[1] - obs.player[1]) / tile
            if not d.name:
                if len("".join(ch for ch in d.raw if ch.isalpha())) >= 3:
                    self.diag.log_limited(f"rej-{d.raw}-{int(d.box[0]//90)}-{int(d.box[1]//90)}", self.c.reject_log_interval_s,
                                          t, "descartado", f"'{d.raw}' em ({d.body[0]:.0f},{d.body[1]:.0f}): {d.reason}", self.state.value)
                continue
            if d.confidence < self.c.min_pick_confidence:
                reason = f"confiança {d.confidence:.2f} < {self.c.min_pick_confidence:.2f}"
            elif not d.bar_present:
                reason = "sem barra de vida visível (não parece monstro vivo)"
            elif obs.blind(d.body[0], d.body[1], 0.4 * tile):
                reason = "sob a interface ou fora da tela"
            elif dist > self.c.max_range_tiles:
                reason = f"fora do alcance ({dist:.1f}t > {self.c.max_range_tiles:.0f}t)"
            elif any(math.hypot(d.body[0] - b[0], d.body[1] - b[1]) <= b[3] for b in self.blacklist):
                reason = "em quarentena (acabou de ser recusado/abatido nesse ponto)"
            if reason:
                self.diag.log_limited(f"skip-{d.name}-{int(d.box[0]//90)}-{int(d.box[1]//90)}", self.c.reject_log_interval_s,
                                      t, "descartado", f"'{d.name}' em ({d.body[0]:.0f},{d.body[1]:.0f}): {reason}", self.state.value)
                continue
            cands.append((dist - 0.15 * self.priority.get(d.name, 0), d, dist))
        if not cands:
            return
        cands.sort(key=lambda c: c[0])
        _, d, dist = cands[0]
        alts = [(c[1].name, round(c[1].body[0]), round(c[1].body[1]), round(c[2], 1)) for c in cands[1:4]]
        self._start_target(obs, d, origin="bot",
                           why=f"mais próximo ({dist:.1f}t) entre {len(cands)} candidato(s) válido(s); conf={d.confidence:.2f} cor={d.color_score:.2f}",
                           alternatives=alts)
        self.sel_started = t
        self.reselect = False
        self._goto(State.ALVO_SELECIONADO, f"aguardando o jogo confirmar a seleção de '{d.name}'", t)
        self._tap_track(obs, f"selecionar '{d.name}'")

    def _start_target(self, obs: Observation, det: NameDetection, origin: str, why: str, **data) -> None:
        if self.track is not None:                      # GUARDA: impossível por construção, mas registrado se ocorrer
            self.diag.log(obs.t, "troca_bloqueada", "tentativa de iniciar alvo com outro ainda ativo — bloqueada",
                          self.state.value, atual=self.track.serial)
            self.stats["troca_bloqueada"] += 1
            return
        self._serial += 1
        self.track = self.tracker.new_track(self._serial, det, obs.t, origin)
        self.verifier.reset()
        self.inactive_since = None
        self.stats["alvos"] += 1
        if self.last_release_serial is not None:
            self.diag.log(obs.t, "troca", f"troca de alvo: #{self.last_release_serial} liberado por '{self.last_release_reason}' "
                          f"→ novo alvo #{self._serial} '{det.name}'", self.state.value)
            self.stats["trocas"] += 1
        self.diag.log(obs.t, "selecionado", f"alvo #{self._serial} '{det.name}' em ({det.body[0]:.0f},{det.body[1]:.0f}) [{origin}]: {why}",
                      self.state.value, name=det.name, pos=det.body, conf=det.confidence, **data)

    # ------------------------------------------------------------------ ALVO_SELECIONADO
    def _selected(self, obs: Observation) -> None:
        t, trk = obs.t, self.track
        m = self._match(obs)
        if m.foreign_frame is not None:
            self.stats["selecionou_outro"] += 1
            fd = m.foreign_det.name if m.foreign_det else "?"
            self.diag.log_limited(f"foreign-{trk.serial}", 1.0, t, "conflito",
                                  f"o jogo selecionou OUTRO monstro ('{fd}' em {m.foreign_frame.center[0]:.0f},{m.foreign_frame.center[1]:.0f}) "
                                  f"em vez do alvo #{trk.serial} '{trk.name}' — não adoto; reforço o original", self.state.value)
            if m.found:
                self._tap_track(obs, "reforçar o alvo original (moldura do jogo caiu em outro monstro)")
        elif m.found and obs.portrait_active and (m.frame_on_target or (not obs.frames and self._portrait_fresh(obs))):
            trk.selected_confirmed, trk.engaged_at = True, t
            self.stale_sig = None
            self.reselect = False
            self._goto(State.ATACANDO, f"seleção confirmada pelo jogo (retrato ativo; identidade por {m.how}; custo {m.cost:.2f})", t)
            return
        if not m.found and t - trk.last_seen >= self.c.lost_after_s:
            self._goto(State.ALVO_TEMPORARIAMENTE_PERDIDO, f"alvo não visto há {t - trk.last_seen:.1f}s durante a seleção", t)
            return
        if t - self.sel_started > self.c.select_confirm_timeout_s:
            if trk.taps < self.c.max_select_retries and m.found:
                self.sel_started = t
                self.stats["retoques"] += 1
                self._tap_track(obs, f"seleção não confirmada em {self.c.select_confirm_timeout_s:.1f}s: tocar de novo o MESMO alvo")
            elif trk.taps >= self.c.max_select_retries and t - self.sel_started > self.c.select_confirm_timeout_s:
                self._release(obs, "selecao_recusada", note=f"{trk.taps} toques sem o jogo confirmar a seleção")

    # ------------------------------------------------------------------ ATACANDO
    def _attacking(self, obs: Observation) -> None:
        t, trk = obs.t, self.track
        m = self._match(obs)
        if m.foreign_frame is not None:
            self.stats["selecionou_outro"] += 1
            self.diag.log_limited(f"foreign-{trk.serial}", 1.0, t, "conflito",
                                  f"moldura do jogo em outro monstro durante o ataque ao #{trk.serial} — mantenho o alvo original",
                                  self.state.value)
        if m.found:
            if obs.portrait_active or m.frame_on_target:
                self.inactive_since = None
            else:
                if self.inactive_since is None:
                    self.inactive_since = t
                elif t - self.inactive_since >= self.c.reselect_after_s:
                    self.stats["reselecoes"] += 1
                    self.reselect = True
                    self.sel_started = t
                    self._goto(State.ALVO_SELECIONADO, f"retrato apagou há {t - self.inactive_since:.1f}s com o alvo vivo e visível "
                               f"→ reselecionar o MESMO alvo (sem trocar)", t)
                    self._tap_track(obs, "reselecionar o mesmo alvo")
                    return
            ref = trk.last_damage_t if trk.last_damage_t is not None else (trk.engaged_at or t)
            if t - ref > self.c.no_damage_alarm_s:
                self.diag.log_limited(f"nodmg-{trk.serial}", 5.0, t, "alerta",
                                      f"alvo #{trk.serial} sem redução de vida há {t - ref:.0f}s (mantendo o alvo)", self.state.value)
            return
        gap = t - trk.last_seen
        if gap >= self.c.lost_after_s:
            if not obs.frames and (not obs.portrait_active or self._low_hp(trk, t)):
                self.verify_started = t
                self.verifier.reset()
                self._goto(State.VERIFICANDO_MORTE, f"alvo sumiu há {gap:.1f}s e a moldura de seleção sumiu "
                           + ("(retrato apagado)" if not obs.portrait_active else "(retrato ainda aceso, mas a vida estava baixa)"), t)
            else:
                self._goto(State.ALVO_TEMPORARIAMENTE_PERDIDO,
                           f"alvo não visto há {gap:.1f}s, mas o jogo ainda mantém a seleção: provável oclusão — mantendo o alvo", t)

    # ------------------------------------------------------------------ ALVO_TEMPORARIAMENTE_PERDIDO
    def _lost(self, obs: Observation) -> None:
        t, trk = obs.t, self.track
        hidden_for = t - trk.last_seen
        m = self._match(obs)
        if m.found:
            self.stats["recuperacoes"] += 1
            self.diag.log(t, "recuperado", f"alvo #{trk.serial} '{trk.name}' recuperado por {m.how} a {m.dist_tiles:.1f}t da previsão "
                          f"(invisível por {hidden_for:.1f}s)", self.state.value, cost=m.cost)
            self._resume(obs, m, f"alvo #{trk.serial} recuperado por {m.how}")
            return
        if not obs.frames and (not obs.portrait_active or self._low_hp(trk, t)):
            self.verify_started = t
            self.verifier.reset()
            self._goto(State.VERIFICANDO_MORTE, "alvo invisível, moldura de seleção sumiu e " +
                       ("o retrato apagou" if not obs.portrait_active else "a vida estava baixa antes de sumir"), t)
            return
        gap = t - trk.last_seen
        if gap >= self.c.lost_alarm_s:
            self.diag.log_limited(f"lost-{trk.serial}", 5.0, t, "alerta",
                                  f"alvo #{trk.serial} invisível há {gap:.0f}s, mas o jogo mantém a seleção — NÃO troco de alvo", self.state.value)

    # ------------------------------------------------------------------ VERIFICANDO_MORTE
    def _verify(self, obs: Observation) -> None:
        t, trk = obs.t, self.track
        m = self._match(obs)
        blind = obs.blind(trk.pos[0], trk.pos[1], 0.4 * obs.tile)
        probe = thumb_diff(trk.thumb, obs.probe_thumb) if obs.probe_thumb is not None else 0.0
        v = self.verifier.update(t, seen_alive=m.found, portrait_active=obs.portrait_active,
                                 frame_present=bool(obs.frames), perception_ok=obs.perception_ok, blind=blind,
                                 recent_min_fill=trk.recent_min_fill(t, 6.0), probe_diff=probe)
        if v.status == "alive":
            self.stats["falsos_alarmes_morte"] += 1
            self.diag.log(t, "falso_alarme", f"alvo #{trk.serial} visto vivo durante a verificação de morte — NÃO era morte", self.state.value)
            self._resume(obs, m, "alvo visto vivo")
            return
        if v.status == "confirmed":
            self._release(obs, "morte_confirmada", verdict=v)
            return
        self.diag.log_limited(f"verify-{trk.serial}", 0.5, t, "verificando",
                              f"{v.status}: " + "; ".join(v.reasons) + f" (exige {v.needed:.1f}s)", self.state.value, **v.evidence)
        if (obs.portrait_active and not self._low_hp(trk, t) or bool(obs.frames)) and not m.found:
            self._goto(State.ALVO_TEMPORARIAMENTE_PERDIDO, "o jogo ainda mostra a seleção (retrato/moldura) sem o alvo visível — não é morte confirmada", t)
            return
        limit = self.c.death_verify_timeout_s * (2 if v.status == "blind" else 1)
        if t - self.verify_started > limit:
            self._release(obs, "perdido_nao_confirmado", verdict=v,
                          note="o jogo soltou o alvo e a morte não pôde ser provada — NÃO conta como abate")

    # ------------------------------------------------------------------ LIBERANDO_ALVO
    def _release(self, obs: Observation, reason: str, verdict: Optional[Verdict] = None, note: str = "") -> None:
        t, trk = obs.t, self.track
        confirmed = reason == "morte_confirmada"
        dur = t - trk.t0
        data = {"alvo": trk.serial, "nome": trk.name, "duracao_s": round(dur, 1), "origem": trk.origin}
        if verdict:
            data["evidencias"] = verdict.reasons
        self.diag.log(t, "liberado", f"alvo #{trk.serial} '{trk.name}' liberado — motivo: {reason}" + (f" ({note})" if note else ""),
                      self.state.value, **data)
        self.stats["mortes" if confirmed else f"liberado_{reason}"] += 1
        self.gate.release(trk.serial)
        r = (0.6 if confirmed else 1.0) * obs.tile
        self.blacklist.append([trk.pos[0], trk.pos[1], t + (3.0 if confirmed else self.c.blacklist_s), r])
        self.last_release_reason, self.last_release_serial = reason, trk.serial
        self.stale_sig = obs.portrait_sig if obs.portrait_active else None
        self.track = None
        self.verifier.reset()
        self.next_search_at = t + self.c.post_release_delay_s
        self._goto(State.LIBERANDO_ALVO, reason, t)

    def _finish_release(self, obs: Observation) -> None:
        self._goto(State.PROCURANDO, "alvo anterior encerrado; buscando o próximo", obs.t)
