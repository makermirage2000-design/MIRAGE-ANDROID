"""Evidências de SELEÇÃO vindas do próprio jogo:
  • retrato do alvo (disco colorido no topo-direito) — acende quando há alvo selecionado
  • moldura quadrada em volta do sprite selecionado (vermelha na caverna, escura no campo)
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional, Tuple

import cv2
import numpy as np

from .config import Config
from .geometry import Layout


@dataclass
class Portrait:
    active: bool
    ratio: float          # fração do disco com cor saturada
    hue: float


@dataclass
class FrameHit:
    center: Tuple[float, float]
    kind: str             # 'red' | 'dark'
    score: float          # correlação com o anel (0..1)


class SelectionReader:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.v = cfg.vision
        self._rings = {}

    def portrait(self, hsv: np.ndarray, lay: Layout) -> Portrait:
        x0, y0, x1, y1 = lay.portrait
        roi = hsv[y0:y1, x0:x1]
        col = (roi[..., 1] > 120) & (roi[..., 2] > 50)
        ratio = float(col.mean())
        hue = float(np.median(roi[..., 0][col])) if ratio > 0.02 else -1.0
        return Portrait(ratio >= self.v.portrait_min_ratio, ratio, hue)

    # ---- moldura: correlação com um anel quadrado, só em janelas pequenas ----
    def _ring(self, side: int, thick: int) -> np.ndarray:
        key = (side, thick)
        if key not in self._rings:
            r = np.zeros((side, side), np.float32)
            r[:thick, :] = 1; r[-thick:, :] = 1; r[:, :thick] = 1; r[:, -thick:] = 1
            self._rings[key] = r
        return self._rings[key]

    def frame_near(self, bgr: np.ndarray, hsv: np.ndarray, center: Tuple[float, float],
                   radius: float, lay: Layout) -> Optional[FrameHit]:
        """Procura a moldura de seleção com centro a até `radius` px de `center`."""
        tile = lay.tile(self.v.ref_tile_px)
        side = int(round(tile)); thick = max(2, int(round(self.v.frame_thickness * lay.s)))
        pad = side // 2 + int(radius) + 2
        cx, cy = int(center[0]), int(center[1])
        x0, y0 = max(0, cx - pad), max(0, cy - pad)
        x1, y1 = min(lay.w, cx + pad), min(lay.h, cy + pad)
        if x1 - x0 < side or y1 - y0 < side:
            return None
        win = hsv[y0:y1, x0:x1]
        masks = {
            "red": (cv2.inRange(win, (0, 200, 150), (8, 255, 255)) | cv2.inRange(win, (172, 200, 150), (180, 255, 255))),
            "dark": cv2.inRange(win, (0, 0, 0), (180, 255, 42)),
        }
        ring = self._ring(side, thick)
        best: Optional[FrameHit] = None
        for kind, m in masks.items():
            res = cv2.matchTemplate((m > 0).astype(np.float32), ring, cv2.TM_CCOEFF_NORMED)
            _, mx, _, loc = cv2.minMaxLoc(res)
            if mx < self.v.frame_min_score:
                continue
            c = (x0 + loc[0] + side / 2, y0 + loc[1] + side / 2)
            if np.hypot(c[0] - center[0], c[1] - center[1]) > radius:
                continue
            if best is None or mx > best.score:
                best = FrameHit(c, kind, float(mx))
        return best
