package br.local.miragehunter;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Serviço de acessibilidade: tira prints da tela do jogo (Android 11+), entrega ao bot (Python)
 * e executa os toques que o bot decidir. Só age quando o jogo está em primeiro plano.
 */
public class HunterService extends AccessibilityService {
    public static volatile HunterService instance;
    public static volatile String status = "Serviço de acessibilidade desligado";

    /** Pacotes do jogo (original e versão câmera ampla). */
    static final Set<String> GAME_PACKAGES = new HashSet<>(Arrays.asList(
            "com.foxcake.mirage.android", "br.local.mirage.cameraampla"));
    private static final long PERIOD_MS = 450;     // intervalo entre quadros (o Android limita ~3 prints/s)

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean running = false;
    private volatile boolean dryMode = true;
    private volatile String foreground = "";
    private PyObject bot;
    private long t0;

    @Override
    protected void onServiceConnected() {
        instance = this;
        status = "Serviço ativo. Abra o app e toque em INICIAR.";
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.getPackageName() != null) {
            foreground = event.getPackageName().toString();
        }
    }

    @Override
    public void onInterrupt() {
        running = false;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        running = false;
        instance = null;
        status = "Serviço de acessibilidade desligado";
        return super.onUnbind(intent);
    }

    // ------------------------------------------------------------------ controle (chamado pela tela)
    public void startHunting(final boolean dry, final String targetsCsv) {
        if (running) return;
        running = true;
        dryMode = dry;
        status = "Iniciando…";
        worker.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    initBot(dry, targetsCsv);
                    t0 = SystemClock.elapsedRealtime();
                    status = dry ? "Rodando em MODO TESTE (não toca na tela). Abra o jogo."
                                 : "Rodando. Abra o jogo.";
                    schedule(0);
                } catch (Throwable ex) {
                    running = false;
                    status = "Erro ao iniciar: " + ex;
                }
            }
        });
    }

    public void stopHunting() {
        running = false;
        status = "Parado";
    }

    public boolean isRunning() {
        return running;
    }

    // ------------------------------------------------------------------ bot
    private void initBot(boolean dry, String targetsCsv) throws Exception {
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(getApplicationContext()));
        }
        File dir = getFilesDir();
        File model = new File(dir, "tessdata/eng.traineddata");
        if (!model.exists()) {
            model.getParentFile().mkdirs();
            try (InputStream in = getAssets().open("tessdata/eng.traineddata");
                 OutputStream out = new FileOutputStream(model)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
        }
        OcrBridge ocr = new OcrBridge(dir);
        PyObject module = Python.getInstance().getModule("android_entry");
        bot = module.callAttr("create", ocr, new TapBridge(this), dir.getAbsolutePath(), targetsCsv, dry);
    }

    private void schedule(long delayMs) {
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                tick();
            }
        }, delayMs);
    }

    private void tick() {
        if (!running) return;
        boolean inGame = GAME_PACKAGES.contains(foreground);
        if (!inGame && !(dryMode && foreground.isEmpty())) {
            status = "Aguardando o jogo ficar em primeiro plano (agora: " + foreground + ")";
            schedule(700);
            return;
        }
        takeScreenshot(Display.DEFAULT_DISPLAY, worker, new TakeScreenshotCallback() {
            @Override
            public void onSuccess(ScreenshotResult result) {
                handleFrame(result);
            }

            @Override
            public void onFailure(int errorCode) {
                status = "Falha na captura de tela (código " + errorCode + ")";
                schedule(1000);
            }
        });
    }

    /** Roda na thread "worker": salva o quadro bruto, chama o Python e agenda o próximo. */
    private void handleFrame(ScreenshotResult result) {
        long start = SystemClock.elapsedRealtime();
        try {
            HardwareBuffer hb = result.getHardwareBuffer();
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, result.getColorSpace());
            if (hw == null) throw new IllegalStateException("captura vazia");
            Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
            hb.close();
            int w = sw.getWidth(), h = sw.getHeight(), stride = sw.getRowBytes() / 4;
            ByteBuffer bb = ByteBuffer.allocateDirect(sw.getByteCount());
            sw.copyPixelsToBuffer(bb);
            bb.rewind();
            File f = new File(getCacheDir(), "frame.raw");
            try (FileOutputStream fos = new FileOutputStream(f); FileChannel ch = fos.getChannel()) {
                while (bb.hasRemaining()) ch.write(bb);
            }
            sw.recycle();
            hw.recycle();
            double t = (SystemClock.elapsedRealtime() - t0) / 1000.0;
            String json = bot.callAttr("process", f.getAbsolutePath(), w, h, stride, t).toString();
            JSONObject o = new JSONObject(json);
            status = (dryMode ? "[TESTE] " : "") + o.getString("estado") + " | alvo " + o.getString("alvo")
                    + " | nomes lidos: " + o.getInt("nomes") + " | mortes: " + o.getInt("mortes")
                    + " | trocas: " + o.getInt("trocas") + " | toques: " + o.getInt("toques")
                    + " | " + o.getInt("ms") + " ms\n" + o.getString("msg");
        } catch (Throwable ex) {
            status = "Erro no processamento: " + ex;
        }
        schedule(Math.max(50, PERIOD_MS - (SystemClock.elapsedRealtime() - start)));
    }

    // ------------------------------------------------------------------ toque
    public boolean tapAt(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, 60);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        return dispatchGesture(gesture, null, null);
    }
}
