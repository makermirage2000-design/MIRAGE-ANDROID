package br.local.miragehunter;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.RandomAccessFile;

/** Tela simples: ativar acessibilidade, escolher monstros, iniciar/parar, compartilhar diagnóstico. */
public class MainActivity extends Activity {
    private static final String DEFAULT_TARGETS =
            "Spider, Raging Spider, Elite Spider, Imp, Elite Imp, Frozen Imp, Troll, Raging Troll";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView statusView;
    private EditText targetsEdit;
    private CheckBox dryBox;
    private SharedPreferences prefs;

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            statusView.setText(HunterService.status);
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("hunter", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Mirage Hunter");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("1) Ative o serviço de acessibilidade \"Mirage Hunter\".\n"
                + "2) Escolha os monstros permitidos.\n"
                + "3) Toque em INICIAR e abra o jogo.\n"
                + "Comece com o MODO TESTE ligado: o bot só observa e registra, sem tocar na tela.");
        root.addView(help);

        Button access = new Button(this);
        access.setText("1. Abrir configurações de acessibilidade");
        access.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        root.addView(access);

        targetsEdit = new EditText(this);
        targetsEdit.setText(prefs.getString("targets", DEFAULT_TARGETS));
        targetsEdit.setHint("Monstros permitidos, separados por vírgula");
        root.addView(targetsEdit);

        dryBox = new CheckBox(this);
        dryBox.setText("MODO TESTE (não toca na tela)");
        dryBox.setChecked(prefs.getBoolean("dry", true));
        root.addView(dryBox);

        Button start = new Button(this);
        start.setText("2. INICIAR");
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.edit().putString("targets", targetsEdit.getText().toString())
                        .putBoolean("dry", dryBox.isChecked()).apply();
                HunterService s = HunterService.instance;
                if (s == null) {
                    HunterService.status = "Ative primeiro o serviço de acessibilidade (botão 1).";
                } else {
                    s.startHunting(dryBox.isChecked(), targetsEdit.getText().toString());
                }
            }
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("PARAR");
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HunterService s = HunterService.instance;
                if (s != null) s.stopHunting();
            }
        });
        root.addView(stop);

        Button share = new Button(this);
        share.setText("Compartilhar diagnóstico (log)");
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareLog();
            }
        });
        root.addView(share);

        statusView = new TextView(this);
        statusView.setPadding(0, pad, 0, 0);
        root.addView(statusView);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresh);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refresh);
    }

    private void shareLog() {
        try {
            File f = new File(getFilesDir(), "diagnostico.jsonl");
            String text = "(sem log ainda)";
            if (f.exists()) {
                try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
                    long len = raf.length();
                    int n = (int) Math.min(len, 60000);
                    byte[] buf = new byte[n];
                    raf.seek(len - n);
                    raf.readFully(buf);
                    text = new String(buf, "UTF-8");
                }
            }
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(send, "Enviar diagnóstico"));
        } catch (Exception ex) {
            HunterService.status = "Não foi possível ler o log: " + ex;
        }
    }
}
