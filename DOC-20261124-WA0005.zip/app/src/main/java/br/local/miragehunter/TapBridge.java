package br.local.miragehunter;

/** Ponte de toque chamada pelo Python. */
public class TapBridge {
    private final HunterService service;

    public TapBridge(HunterService service) {
        this.service = service;
    }

    public boolean tap(float x, float y) {
        return service.tapAt(x, y);
    }
}
