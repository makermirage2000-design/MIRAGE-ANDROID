package br.local.miragehunter;

import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.File;

/** OCR de uma linha de texto (nome do monstro). Chamado pelo Python (android_entry.py). */
public class OcrBridge {
    private final TessBaseAPI api = new TessBaseAPI();

    /** dataDir precisa conter a pasta "tessdata" com eng.traineddata. */
    public OcrBridge(File dataDir) {
        if (!api.init(dataDir.getAbsolutePath(), "eng")) {
            throw new IllegalStateException("Tesseract não iniciou (tessdata em " + dataDir + ")");
        }
        api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_LINE);
        api.setVariable(TessBaseAPI.VAR_CHAR_WHITELIST, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz");
        api.setVariable("preserve_interword_spaces", "1");
    }

    /** Devolve "texto<TAB>confiança(0-100)". */
    public synchronized String recognize(String pngPath) {
        api.setImage(new File(pngPath));
        String text = api.getUTF8Text();
        int conf = api.meanConfidence();
        api.clear();
        if (text == null) text = "";
        return text.replace('\n', ' ').replace('\t', ' ').trim() + "\t" + conf;
    }
}
